#pragma once
#include <chrono>
#include <memory>
#include <string>
#include <unistd.h>
#include <bits/stdc++.h>

#if (defined(SUPPORT_ROS1_JPG) || defined(SUPPORT_ROS1_YUV))
#include "ros/ros.h"
#include "sensor_msgs/CompressedImage.h"

/**
 * @class CCameraPublisher
 * @brief ROS1图像发布器类，用于发布压缩图像消息
 *
 * 此类封装了ROS1的压缩图像发布功能，简化了图像数据的发布过程
 */
class CCameraPublisher
{
public:
    /**
     * @brief CCameraPublisher 构造函数
     *
     * 使用给定的话题名称创建图像发布器
     *
     * @param name 话题名称（如"cam0/compressed"）
     */
    CCameraPublisher(std::string name);

    /**
     * @brief CCameraPublisher 类的析构函数
     *
     * 释放资源，清理ROS相关对象
     */
    ~CCameraPublisher();

    /**
     * @brief 发布压缩图像消息
     *
     * 将图像数据封装为ROS消息并发布到指定话题
     *
     * @param stTime 图像时间戳
     * @param pData 图像数据指针
     * @param nDatalen 图像数据长度
     * @return 成功发布返回true，否则返回false
     */
    bool Publisher(struct timespec stTime, unsigned char *pData, int nDatalen);

private:
    char m_szTopic[128];            ///< 话题名称
    ros::Publisher m_Publisher;     ///< ROS发布者对象
    ros::NodeHandle m_nh;           ///< ROS节点句柄
};
#endif

#if (defined(SUPPORT_ROS2_JPG) || defined(SUPPORT_ROS2_YUV))
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/image.hpp"
#include "sensor_msgs/msg/compressed_image.hpp"

class CCameraPublisher : public rclcpp::Node
{
public:
    /**
     * @brief CCameraPublisher 构造函数
     *
     * 使用给定的相机配置和发布器创建 CCameraPublisher 对象。
     *
     * @param camCfg 相机配置
     * @param publisher 发布器指针
     */
    CCameraPublisher(std::string name);

    /**
     * @brief CCameraPublisher 类的析构函数
     *
     * CCameraPublisher 类的析构函数，用于释放资源。
     */
    ~CCameraPublisher();

    bool Publisher(struct timespec stTime, unsigned char *pData, int nDatalen);

private:
    char m_szTopic[128];
    rclcpp::Publisher<sensor_msgs::msg::CompressedImage>::SharedPtr m_Publisher;
};
#endif