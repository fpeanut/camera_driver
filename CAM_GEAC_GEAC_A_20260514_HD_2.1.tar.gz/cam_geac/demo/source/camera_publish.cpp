#if (defined(SUPPORT_ROS1_JPG) || defined(SUPPORT_ROS1_YUV))
#include "../inc/camera_publish.h"

/**
 * @brief CCameraPublisher构造函数
 * 
 * 初始化ROS节点并创建图像发布者
 * 
 * @param name 话题名称
 */
CCameraPublisher::CCameraPublisher(std::string name)
{
    // 保存话题名称
    strncpy(m_szTopic, name.c_str(), sizeof(m_szTopic));
    m_szTopic[sizeof(m_szTopic) - 1] = '\0'; // 确保字符串终止
    
    // 创建CompressedImage类型发布者，队列大小为2
    m_Publisher = m_nh.advertise<sensor_msgs::CompressedImage>(name, 2);
}

/**
 * @brief CCameraPublisher析构函数
 * 
 * 清理资源，ROS1会自动管理大部分资源
 */
CCameraPublisher::~CCameraPublisher()
{
    // 析构函数（当前无资源需要显式释放，ROS1资源会自动管理）
}

/**
 * @brief 发布压缩图像消息
 * 
 * 将图像数据封装为ROS消息并发布
 * 
 * @param stTime 图像时间戳
 * @param pData 图像数据指针
 * @param nDatalen 图像数据长度
 * @return 总是返回true表示成功
 */
bool CCameraPublisher::Publisher(struct timespec stTime, unsigned char *pData, int nDatalen)
{
    // 检查数据有效性
    if (pData == nullptr || nDatalen <= 0) {
        // ROS_WARN("Invalid image data: null pointer or zero length");
        return false;
    }
    
    // 创建压缩图像消息对象
    sensor_msgs::CompressedImage image_msg;
    
    // 填充消息头信息
    image_msg.header.stamp.sec = stTime.tv_sec;
    image_msg.header.stamp.nsec = stTime.tv_nsec;
    image_msg.header.frame_id = m_szTopic;

    // 配置图像数据参数
    image_msg.data.resize(nDatalen);
    image_msg.format = "jpeg";

    // 数据填充
    std::memcpy(&image_msg.data[0], pData, nDatalen);
    
    // 发布消息
    m_Publisher.publish(image_msg);
    
    // 输出调试信息
    // ROS_INFO("Published compressed image on %s, size: %d bytes", m_szTopic, nDatalen);

    return true;
}
#endif

#if (defined(SUPPORT_ROS2_JPG) || defined(SUPPORT_ROS2_YUV))
#include "../inc/camera_publish.h"

// 构造函数初始化ROS2节点和图像发布者
// 参数name指定发布话题的名称
CCameraPublisher::CCameraPublisher(std::string name)
 :rclcpp::Node("Image_publisher")  // 创建ROS2节点，固定节点名称为"Image_publisher"
{
 m_Publisher = this->create_publisher<sensor_msgs::msg::CompressedImage>(name, 2); 
    // 创建CompressedImage类型发布者：
    // name参数指定具体话题名称（如"/camera/image/compressed"）
    // 2表示消息队列缓存深度（缓冲未及时处理的消息）
}

CCameraPublisher::~CCameraPublisher()
{
    // 析构函数（当前无资源需要显式释放，ROS2资源会自动管理）
}

bool CCameraPublisher::Publisher(struct timespec stTime, unsigned char *pData, int nDatalen)
{
    // 创建压缩图像消息对象
    sensor_msgs::msg::CompressedImage image_msg;
    
    // 填充消息头信息
    image_msg.header.stamp.sec = stTime.tv_sec;        // 时间戳秒级部分（来自设备采集时间）
    image_msg.header.stamp.nanosec = stTime.tv_nsec;   // 时间戳纳秒级部分
    image_msg.header.frame_id = m_szTopic;             // 坐标系标识（通常与话题名关联）

    // 配置图像数据参数
    image_msg.data.resize(nDatalen);                   // 预分配数据空间（精确匹配输入数据长度）
    image_msg.format = "jpeg";                         // 指定编码格式（固定为JPEG格式，确保ROS2客户端兼容性）

    // 数据填充与发布
    std::memcpy(image_msg.data.data(), (unsigned char *)pData, image_msg.data.size()); 
        // 直接复制原始压缩数据到消息缓冲区（需确保pData指向有效且长度匹配）
    m_Publisher->publish(image_msg); 
        // 将消息推入发布队列（实际网络传输由ROS2底层异步完成）

    return true; // 成功发布返回状态
}
#endif
